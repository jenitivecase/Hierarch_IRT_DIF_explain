#MSUB -N IRT_DIF_rho08_pref09_mu05_alpha09
#MSUB -l nodes=1:ppn=3,walltime=60:00:00:00
#MSUB -l pmem=12gb
#MSUB -M jbrussow@ku.edu
#MSUB -m abe 
#MSUB -j oe 
#MSUB -q crmda
#MSUB -o IRT_DIF_rho08_pref09_mu05_alpha09.log


cd $PBS_O_WORKDIR
module purge
module use /panfs/pfs.local/work/crmda/tools/modules
module load Rstats/3.3

R -f cluster_base_script.R --args seed_index=18 rho=0.8 P_REF=0.9 mu2=0.5 alpha=0.9